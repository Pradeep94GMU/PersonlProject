package com.pradeep.PaymentSys;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaymentSysApplicationTests {

	@Test
	void contextLoads() {
	}

}
