package com.pradeep.PaymentSys;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaymentSysApplication {

	public static void main(String[] args) {
		SpringApplication.run(PaymentSysApplication.class, args);
	}

}
