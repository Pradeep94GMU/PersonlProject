package com.pradeep.Insurance.Policy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InsurancePolicyApplication {

	public static void main(String[] args) {
		SpringApplication.run(InsurancePolicyApplication.class, args);
	}

}
