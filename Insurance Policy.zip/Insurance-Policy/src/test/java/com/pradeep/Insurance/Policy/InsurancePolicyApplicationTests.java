package com.pradeep.Insurance.Policy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InsurancePolicyApplicationTests {

	@Test
	void contextLoads() {
	}

}
